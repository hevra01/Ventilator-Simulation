/*
    Author: Hevra Petekkaya 2456200
    Description: This is a headerFile that will provide linked list supporting functions to the ventilator Simulation program.

                                                                                                                            */

#include "queueADT.h"
/* A function that creates a linked list */
record createLinkedList(void);
void appendToPatientList(record recordList, int Id, char patientType, int arrivalTime, int serviceTime, int serviceStartTime, int ventilatorId, int gender, int ageGroup, int timePastSinceServiceStart);
void addToLinkedList(patient temp, record listRecord);
void RemoveSearchPatient(record patientQueue, int Id);
