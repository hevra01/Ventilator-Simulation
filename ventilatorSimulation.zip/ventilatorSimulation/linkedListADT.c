/*
    Author: Hevra Petekkaya 2456200
    Description: This is a headerFile that will provide linked list supporting functions to the ventilator Simulation program.

                                                                                                                            */
#include<stdio.h>
#include<stdlib.h>
#include "linkedListADT.h"
#include <stdbool.h>

/* A function that creates a linked list */
record createLinkedList(void)
{
 	record recordList;
 	if (! (recordList = (record) malloc(sizeof(struct patientListRecord)))) {
        printf("Unsuccessful memory allocation!");
        exit(1);
    }
    recordList -> size = 0;
    if (! (recordList -> front = (patient) malloc(sizeof(struct Patient)))) {
        printf("Unsuccessful memory allocation!");
        exit(1);
    }
    recordList -> front -> next = (recordList -> rear = NULL);
    return recordList;
}

void appendToPatientList(record recordList, int Id, char patientType, int arrivalTime, int serviceTime, int serviceStartTime, int ventilatorId, int gender, int ageGroup, int timePastSinceServiceStart) {
    patient temp, temp2 = recordList -> front , temp3;
    // Allocate a temporary patient node and check if it was successful.
    if (! (temp = (patient) malloc(sizeof(struct Patient)))) {
        printf("Can't allocate memory.");
        exit(1);
    }
    // Assign the patient information accordingly.
    temp -> patientType = patientType; temp -> arrivalTime = arrivalTime; temp -> serviceTime = serviceTime;
    temp -> gender = gender; temp -> ageGroup = ageGroup; temp -> VentilatorId = ventilatorId;
    temp -> serviceStartTime = serviceStartTime; temp -> timePastSinceServiceStart = timePastSinceServiceStart;
    temp -> Id = Id;
    int found = 0;
    // Append to the patient linkedList based on its order.
    if (! (recordList -> front -> next)) {
        recordList -> front -> next = (recordList -> rear = temp);
        recordList -> rear -> next = NULL;
    } else {
        for (temp2; temp2 -> next && ! found; temp2 = temp2 -> next) {
            if ((temp -> arrivalTime) < (temp2 -> next -> arrivalTime)) {
                temp3 = temp2 -> next;
                temp2 -> next = temp;
                temp -> next = temp3;
                found = 1;
            }
        }
        if (! (temp2 -> next)) {
            temp2 -> next = temp;
            temp -> next = NULL;
            recordList -> rear -> next = temp;
            recordList -> rear = temp;
            recordList -> rear -> next = NULL;
        }
    }
    (recordList -> size) ++;
}

/* This will enqueue to the final patientList in order to obtain the statistics. */
void addToLinkedList(patient temp, record recordList) {
    patient temp2;
    if (! (temp2 = (patient) malloc(sizeof(struct Patient)))) {
        printf("Cant allocate memory!");
        exit(1);
    }
    temp2 -> ageGroup = temp -> ageGroup;
    temp2 -> gender = temp -> gender;
    temp2 -> arrivalTime = temp -> arrivalTime;
   // temp2 -> next = temp -> next;
    temp2 -> serviceStartTime = temp -> serviceStartTime;
    temp2 -> serviceTime = temp -> serviceTime;
    temp2 -> VentilatorId = temp -> VentilatorId;
    temp2 -> patientType = temp -> patientType;
    temp2 -> timePastSinceServiceStart = temp -> timePastSinceServiceStart;
    temp2 -> Id = temp -> Id;
    if ((recordList -> front -> next) == NULL) {
        recordList -> front -> next = (recordList -> rear = temp2);
        recordList -> rear -> next = NULL;
    } else {
        recordList -> rear -> next = temp2;
        recordList -> rear = temp2;
        recordList -> rear -> next = NULL;
    }
    (recordList -> size) ++;
}

/* Delete Node. */
void deleteNode(record q) {
    patient temp;
    if (! (q -> size)) {
        printf("list empty");
    } else if (q -> size == 1) {
        temp = q -> front -> next;
        q -> front -> next = NULL;
        q -> rear = q -> front;
        free(temp);
    } else {
        temp = q -> front -> next;
        q -> front -> next = temp -> next;
        free(temp);
    }
    (q -> size) --;
}
