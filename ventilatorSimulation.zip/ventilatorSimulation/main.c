/*
    Author: Hevra Petekkaya
    Student Id: 2456200
    Description: Ventilator Simulation / Assignment 2
    Due Date: 13 December 2020, Sunday, 23:55 (Cyprus Time)
                                                            */

#include<stdio.h>
#include<stdlib.h>
#include "linkedListADT.h"

/* This structure helps to gather information for the statistics function. */
struct statistics {
    int young, adult, elderly;
    int severe, moderate, mild;
    int male, female;
};

int calculateMaxWaitingTime(record patientList, int* averageWaitingTime);
struct statistics* initializeStatistics(void);
void parseInput(int argc, char **argv, int *inputs);
void createPatientList(int *input, record recordList, struct statistics *statistics);
record initializeSimulator(int *inputs, struct ventilator *ventilatorList);
int randomGenerator(int num);
void newPatient(record patientQueue, record recordList);
void servePatient(int available, int* simulationTime, struct ventilator *ventilator, record patientQueue, record recordList, record patientsBeingServed);
void assignVentilator(record patientQueue, struct ventilator* ventilator, int noVentilator);
void reportStatistics(int *inputs, record recordList, int *simulationTime, struct statistics *statistics, struct ventilator *ventilatorList);

int main(int argc, char *argv[]){
    srand(time(NULL)); // To generate new random numbers every time.
    int inputs[4], i; // This is an array of inputs that stores the values that the user inputted at the command line.
    record recordList, patientQueue;
    struct statistics* statistics;

    // This will assign values to the important information regarding the patients, which were given in the command line, to their respective variable.
    parseInput(argc, argv, inputs);
    struct ventilator ventilatorList[inputs[1]]; // A ventilator array with size depending on the command line input.
    statistics = initializeStatistics();
    recordList = CreateQueue();
    MakeEmptyQueue(recordList);

    createPatientList(inputs, recordList, statistics); //This will create the patient list based on their arrival times.
    patientQueue = initializeSimulator(inputs, ventilatorList); // This will create the queue and ventilator list.
    newPatient(patientQueue, recordList); // This will put the patients in the queue.

    int simulationTime = patientQueue -> front -> next -> arrivalTime, available;
    record patientsBeingServed;
    patientsBeingServed = CreateQueue(); int j;
    MakeEmptyQueue(patientsBeingServed); patient temp = patientQueue->front->next;
    for(; temp; temp = temp->next)
    // This loop will traverse the patient queue and serve them.
    while ((((patientsBeingServed -> size) > 0) || ((patientQueue->size) >0))) {
        // The ventilators will be assigned whenever they are available.
        for (i = 0; (i < inputs[1]) && ((((patientsBeingServed -> size) > 0) || ((patientQueue->size) > 0))); i++) {
            /* Here a new patient will be served since there is a ventilator available and their are patients who still have not been served.
               It will also make sure if the patient have arrived or not. It will do this by  comparing the arrivalTime of
               The patient and the simulationTime. If the simulationTime is less than the arrival time,
               It means the patients has not arrived yet so it can not be served. */
            if(patientQueue->front->next){
                 if ((ventilatorList[i].available) && ((patientQueue->front->next -> arrivalTime) <= simulationTime)) {
                    (patientQueue->front->next -> VentilatorId) = i + 1;
                    ventilatorList[i].available = 0;
                    // This will give a signal to the serve function that a new patient can be served since there is a ventilator.
                    available = 1;
                    servePatient(available, &simulationTime, ventilatorList, patientQueue, recordList, patientsBeingServed);
                    if (patientQueue->front->next == NULL) patientQueue->size = 0;
                 } else {
                    // This will signal that there are no available ventilators so only continue serving the patients currently having a ventilator.
                    available = 0;
                    servePatient(available, &simulationTime, ventilatorList, patientQueue, recordList, patientsBeingServed);
                 }
            // Here no new patient will be added only the ones in the patientsBeingServed list will continue to being served.
            } else {
                // This will signal that there are no available ventilators so only continue serving the patients currently having a ventilator.
                available = 0;
                servePatient(available, &simulationTime, ventilatorList, patientQueue, recordList, patientsBeingServed);
            }
        }
    }
    // This function will report the statistics.
    reportStatistics(inputs, recordList, &simulationTime, statistics, ventilatorList);
    return 0;
}

/* This function takes a patient from the queue to be served by a ventilator. */
void servePatient(int available, int* simulationTime, struct ventilator *ventilator, record patientQueue, record recordList, record patientsBeingServed) {
    patient tempPatient, remove;
    if (available) {
        patientQueue->front->next -> serviceStartTime = (*simulationTime);
        appendToPatientList(patientsBeingServed, patientQueue->front->next -> Id, patientQueue->front->next->patientType, patientQueue->front->next -> arrivalTime, patientQueue->front->next -> serviceTime, patientQueue->front->next -> serviceStartTime, patientQueue->front->next ->VentilatorId, patientQueue->front->next -> gender, patientQueue->front->next -> ageGroup, patientQueue->front->next -> timePastSinceServiceStart);
        Dequeue(patientQueue);
    } else {
        tempPatient = patientsBeingServed->front->next;
        // The time should flow if the ventilators are free and the patients have not arrived yet.
        if (tempPatient == NULL) (*simulationTime) ++;
        for (; tempPatient; ) {
            /* If the serving time of the ventilator for the patient hasn't been completed yet,
               the ventilator is still considered to be unavailable. So we increment the timePastSinceServiceStart
               in order to know the time when the serving will end so that the ventilator can be available again. */
            if ((tempPatient -> timePastSinceServiceStart) != (tempPatient -> serviceTime)) {
                (tempPatient -> timePastSinceServiceStart) ++;
                tempPatient=tempPatient->next;
            // We come here when the service has ended for a particular patient.
            } else {
                // This will keep track of the number of times a ventilator is being used. To be used to report statistics.
                (ventilator[(tempPatient -> VentilatorId) - 1].usedTime) ++;
                // The ventilator will be available after completely serving the patient.
                ventilator[(tempPatient -> VentilatorId) - 1].available = 1;
                ventilator[(tempPatient -> VentilatorId) - 1].completionTime = (tempPatient -> serviceStartTime) + (tempPatient -> serviceTime);
                (*simulationTime) = ventilator[(tempPatient -> VentilatorId) - 1].completionTime;
                // Before we dequeue the patient, we need to add it back to our list so that we can extract the statistics from the list.

                addToLinkedList(tempPatient, recordList);
                remove = tempPatient;
                if(patientsBeingServed->size == 1) {
                    patientsBeingServed->front->next =NULL;
                    tempPatient = NULL;
                } else if (patientsBeingServed->front->next == tempPatient) {
                    patientsBeingServed->front->next =tempPatient->next;
                    tempPatient=tempPatient->next;
                } else {
                    tempPatient=tempPatient->next;
                }
                (patientsBeingServed ->size)--;
                free(remove);
                remove =NULL;
            }
        }
    }
}

/*  This function should parse the input and set the values of the number of
    patients, the number of ventilators, the maximum arrival time and the
    maximum service time. */
void parseInput(int argc, char **argv, int *inputs) {
    int i = 1; // i starts from one to dismiss the first string which is the file name.
    // This if statement prevents the program from continuing to run if the number of inputs passed in the command line are wrong.
    if (argc < 5 || argc > 5) {
        printf("Invalid number of inputs from the command line. \nProgram terminates!");
        exit(1);
    }
    // The for loop traverses the inputs from the command line and assigns values accordingly.
    for (i; i < argc; i++) {
        inputs[i - 1] = atoi(argv[i]);
    }
}

/* This function should randomly create patients based on the input (the number of
   patients, the number of ventilators, the maximum arrival time, the maximum service
   time). The patients should be stored in a linked list in ascending order based on their
   arrival time. */
void createPatientList(int *inputs, record recordList, struct statistics *statistics) {
    int i, Id = 0, arrivalTime, patient, gender, ageGroup, serviceStartTime = 0, serviceTime, ventilatorId = 0, timePastSinceServiceStart = 0;
    char patientType;

    // This for loop assigns values to patient information depending on the inputs that specify the max value for a specific information.
    for (i = 0; i < inputs[0]; i++) {
        patient = randomGenerator(3);
        if (!patient) {
            patientType = 'S';
            (statistics -> severe) ++;
        } else if (patient == 1) {
            patientType = 'D';
            (statistics -> moderate) ++;
        } else {
            patientType = 'M';
            (statistics -> mild) ++;
        }

        gender = randomGenerator(2);
        // This information is collected to be used for reporting the statistics.
        if (gender) {
            (statistics -> male) ++;
        } else {
            (statistics -> female) ++;
        }

        ageGroup = randomGenerator(3);
        // This information is collected to be used for reporting the statistics.
        if (! ageGroup) {
            (statistics -> young) ++;
        } else if (ageGroup == 1) {
            (statistics -> adult) ++;
        } else {
            (statistics -> elderly) ++;
        }
        serviceTime = randomGenerator(inputs[3]) + 1;
        arrivalTime = randomGenerator(inputs[2]) + 1;
        // This function will append the patient and add it to the right order depending on its arrival time.
        // You can see the implementation of the ordering of the patients from the linkedListADT library.
        appendToPatientList(recordList, Id, patientType, arrivalTime, serviceTime, serviceStartTime, ventilatorId, gender, ageGroup, timePastSinceServiceStart);
    }
}

/* This function should create an empty queue, and also an integer
   array to keep the availability of the ventilators. */
record initializeSimulator(int *inputs, struct ventilator *ventilatorList) {
    int i;
    // Create an empty patient queue.
    record patientQueue;
    patientQueue = CreateQueue();
    MakeEmptyQueue(patientQueue);

    // The ventilators are initially available so they are assigned 1.
    for (i = 0; i < inputs[1]; i++) {
        ventilatorList[i].Id = i + 1;
        ventilatorList[i].available = 1;
        ventilatorList[i].usedTime = 0;
        ventilatorList[i].completionTime = 0;
    }
    return patientQueue;
}

/* This function takes a patient from the patient list which was created based on the arrival time and
   add him/her to the queue. */
void newPatient(record patientQueue, record recordList) {
    int Id = 0;
    /* Take patients from the patient list which was made based on arrival time and add them to the patientQueue.
       Then dequeue that patient from the linkedList which was sorted based on the arrivalTime.
       We are dequeuing so that we can add the new modified patient with all of its information after
       serving it (see the servePatient function) so that we can report the statistics properly. */
    while (recordList -> front -> next) {
        Id ++; // This will update the Id of the patients.
        Enqueue(recordList -> front -> next, patientQueue, Id); // The logic for the priority queue has been implemented inside the Enqueue function. (see library queue.h)
        deleteNode(recordList);
    }
}

/* This function generates random numbers based on the max number */
int randomGenerator(int num) {
    return (int) (rand() % num);
}

/* This function reports the statistics, such as the average time spent in
   the queue, maximum waiting time, etc. */
void reportStatistics(int *inputs, record recordList, int *simulationTime, struct statistics *statistics, struct ventilator *ventilatorList) {
    int i, maxWaitingTime, averageWaitingTime;

    // This function will calculate the maximum waiting time.
    maxWaitingTime = calculateMaxWaitingTime(recordList, &averageWaitingTime);

    printf("\n*******Report******\n\n");
    printf("The number of ventilators: %d \nThe number of patients: %d", inputs[1], inputs[0]);

    printf("\nNumber of patients for each ventilator: ");
    // This loop will print the amount of times each ventilator was used by using the data from the ventilator struct.
    for (i = 0; i < inputs[1]; i++) {
        printf("\n  Ventilator %d : %d", i + 1, ventilatorList[i].usedTime);
    }
    // Printing the gathered statistics.
    printf("\n\nNumber of patients for each patient type: \n");
    printf("   Severe: %d \n   Moderate: %d \n   Mild: %d \n\n", statistics -> severe, statistics -> moderate, statistics -> mild);
    printf("\nCompletion time: %d", *simulationTime);
    printf("\nAverage time spent in the queue: %d", averageWaitingTime);
    printf("\nMaximum waiting time: %d", maxWaitingTime);

    // Check for the most gender served from the statistics struct.
    if ((statistics -> female) > (statistics -> male)) {
        printf("\nMost gender usage: Female");
    } else if ((statistics -> female) < (statistics -> male)) {
        printf("\nMost gender usage: Male");
    } else {
        printf("\nMost gender usage: They were equally used.");
    }

    // Check for the most ageGroup served from the statistics struct.
    if ((statistics -> elderly) > (statistics -> young) && (statistics -> elderly) > (statistics -> adult)) {
        printf("\nMost age usage: elderly");
    } else if ((statistics -> adult) > (statistics -> young) && (statistics -> adult) > (statistics -> elderly)) {
        printf("\nMost age usage: adult");
    } else if ((statistics -> young) > (statistics -> adult) && (statistics -> young) > (statistics -> elderly)) {
        printf("\nMost age usage: young");
    } else if ((statistics -> young) == (statistics -> adult) && (statistics -> young) == (statistics -> elderly)) {
        printf("\nMost age usage: All equally used.");
    } else if ((statistics -> young) == (statistics -> adult) && (statistics -> young) > (statistics -> elderly)) {
        printf("\nMost age usage: Young and Adult.");
    } else if ((statistics -> young) == (statistics -> elderly) && (statistics -> young) > (statistics -> adult)) {
        printf("\nMost age usage: Young and Elderly.");
    } else {
        printf("\nMost age usage: Elderly and Adult.");
    }
}

/* This function will initialize the statistics struct. */
struct statistics* initializeStatistics(void) {
    struct statistics *statistics;
    // Allocate memory for the statistics and check if it was successful.
    if (! (statistics = (struct statistics*) malloc(sizeof(struct statistics)))) {
        printf("Unsuccessful memory allocation!");
        exit(1);
    }
    // Initially nothing is generated yet, so they are all equal to zero.
    (statistics -> adult) = 0; (statistics -> elderly) = 0; (statistics -> female) = 0;
    (statistics -> young) = 0; (statistics -> mild) = 0; (statistics -> moderate) = 0;
    (statistics -> severe) = 0; (statistics -> male) = 0;
    return statistics;
}

/* This function will calculate the waiting time for each patient and
   return the max waiting time to be used by the reportStatistics function.
   This function will also serve as freeing the memory because we have received all
   the information we need from the patient list. */
int calculateMaxWaitingTime(record patientList, int* averageWaitingTime) {
    // Maximum waiting time is assumed to be for the first patients.
    // But this is going to change as we traverse through the patient queue.
    int maxWaitingTime = (patientList -> front -> next -> serviceStartTime) - (patientList -> front -> next -> arrivalTime);
    int sumOfWaitingTimes = 0, numberOfPatients = 0;

    while (patientList -> front -> next) {
        numberOfPatients ++;
        sumOfWaitingTimes += ((patientList -> front -> next -> serviceStartTime) - (patientList -> front -> next -> arrivalTime));
        if (maxWaitingTime < ((patientList -> front -> next -> serviceStartTime) - (patientList -> front -> next -> arrivalTime))) {
            maxWaitingTime = ((patientList -> front -> next -> serviceStartTime) - (patientList -> front -> next -> arrivalTime));
        }
        // Dequeue the patient from the list in order to free the memory. Since we no longer need its information.
        Dequeue(patientList);
    }
    (*averageWaitingTime) = sumOfWaitingTimes / numberOfPatients;
    return maxWaitingTime;
}
