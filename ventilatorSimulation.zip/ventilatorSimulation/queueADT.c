#include <stdio.h>
#include <stdlib.h>
#include "queueADT.h"

/* This function initializes the queue */
record CreateQueue()
{
	record myQueue;
	if (! (myQueue = (record) malloc(sizeof(struct patientListRecord)))) {
        printf("Cant allocate memory!");
        exit(1);
	}
	return myQueue;
}

/*This function sets the queue size to 0, and creates a dummy element
and sets the front and rear point to this dummy element*/
void MakeEmptyQueue(record q)
{
    if (! ((q -> front) = (q -> rear) = (patient) malloc(sizeof(struct Patient)))) {
        printf("cant allocate memory");
        exit(1);
    }
	q -> size = 0;
	q -> rear -> next = (q -> front -> next = NULL);
}

/*Shows if the queue is empty*/
int IsEmptyQueue(record q)
{
	if (q -> size) {
        return 0;
	} else {
        return 1;
	}
}

/*Returns the queue size*/
int QueueSize(record q)
{
	return q -> size;
}

/*Enqueue - Adds a new element to the queue, simply creates a node and
adds it to the rear of the queue*/
void Enqueue(patient newPatient, record patientQueue, int Id)
{
	patient node, temp = patientQueue -> front, temp2;
	int patientTypeInt, found;
	if (! (node = (patient) malloc(sizeof(struct Patient)))) {
        printf("cant allocate memory!");
        exit(1);
	}
	node -> ageGroup = newPatient -> ageGroup;
	node -> arrivalTime = newPatient -> arrivalTime;
	node -> gender= newPatient -> gender;
	node -> patientType = newPatient -> patientType;
	node -> serviceStartTime = newPatient-> serviceStartTime;
	node-> serviceTime = newPatient -> serviceTime;
	node -> VentilatorId = newPatient -> VentilatorId;
	node -> timePastSinceServiceStart = newPatient -> timePastSinceServiceStart;
	node -> Id = Id;
	// Assign numerical values to patientType, severe, moderate, mild.
	if ((node -> patientType) == 'S') {
        patientTypeInt = 1;
	} else if ((node -> patientType) == 'D') {
        patientTypeInt = 2;
	} else {
        patientTypeInt = 3;
	}

	if (patientQueue -> front -> next == NULL) {
        patientQueue -> front -> next = (patientQueue -> rear = node);
        patientQueue -> rear -> next = NULL;
	} else {
        if (patientTypeInt == 1) {
            for (; temp && (temp -> next -> patientType) == 'S'; temp = temp -> next) {
                ;
            }
            temp2 = temp -> next;
            temp -> next = node;
            node -> next = temp2;
            if (temp -> next == NULL) {
                patientQueue -> rear -> next = node;
                node -> next = NULL;
                patientQueue -> rear = node;
            }
        } else if (patientTypeInt == 2) {
            for (; temp && temp -> next && (temp -> next -> patientType == 'S' || temp -> next -> patientType == 'D'); temp = temp -> next) {
                ;
            }
            temp2 = temp -> next;
            temp -> next = node;
            node -> next = temp2;
            if (temp -> next == NULL) {
                patientQueue -> rear -> next = node;
                patientQueue -> rear = node;
                node -> next = NULL;
            }
        } else {
            patientQueue -> rear -> next = node;
            patientQueue -> rear = node;
            patientQueue -> rear -> next = NULL;
        }
	}
	(patientQueue -> size) ++;
}

/*Dequeue - Removes a node from the queue, basically removes a node from
the front of the queue*/
void Dequeue(record q)
{
	patient temp;
    if (! (q -> size)) {
        printf("list empty");
    } else if ((q -> size) == 1) {
        temp = q -> front -> next;
        q -> front -> next = NULL;
        q -> rear = q -> front;
        free(temp);
    } else {
        temp = q -> front -> next;
        q -> front -> next = temp -> next;
        free(temp);
    }
    (q->size)--;
}

/*Returns the value stored in the front of the queue*/
int FrontOfQueue(record q)
{
	if (!IsEmptyQueue(q))
		return q -> front -> next -> arrivalTime;
	else
	{
		printf("The queue is empty\n");
		return -1;
	}
}

/*Returns the value stored in the rear of the queue*/
int RearOfQueue(record q)
{
	if (!IsEmptyQueue(q))
		return q -> rear -> arrivalTime;
	else
	{
		printf("The queue is empty\n");
		return -1;
	}
}

