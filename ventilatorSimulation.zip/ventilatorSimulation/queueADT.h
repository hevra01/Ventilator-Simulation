/* This struct holds data about the individual ventilators. */
struct ventilator {
    int Id;
    int usedTime;
    int available;
    int completionTime;
};

/* This struct stores information about the patient. */
struct Patient {
    char patientType;
    int Id, arrivalTime, serviceTime, serviceStartTime, VentilatorId, timePastSinceServiceStart;
    // abstraction: I will store the gender as 0 -> woman and 1 -> male. Age group 2 -> elderly, 1 -> adult, 0 -> young.
    int gender, ageGroup;
    struct Patient *next;
};
typedef struct Patient* patient;

/* This struct stores basic information about the patientLinkedList. */
struct patientListRecord {
    patient front, rear;
    int size;
};
typedef struct patientListRecord* record;

record CreateQueue();
void MakeEmptyQueue(record);
int QueueSize(record);
void Enqueue(patient newPatient, record patientQueue, int Id);
void Dequeue(record);
int FrontOfQueue(record);
int RearOfQueue(record);
int IsEmptyQueue(record);
void DisplayQueue(record);

